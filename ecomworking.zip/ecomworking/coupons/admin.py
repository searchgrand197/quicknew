from django.contrib import admin
from .models import SpecialCoupon, CouponForAll, OneTimeCoupon

@admin.register(SpecialCoupon)
class SpecialCouponAdmin(admin.ModelAdmin):
    list_display = ('code', 'discount_type', 'discount', 'active', 'description')
    list_filter = ('active', 'discount_type')
    search_fields = ('code', 'description')
    filter_horizontal = ('coupon_for',)

@admin.register(CouponForAll)
class CouponForAllAdmin(admin.ModelAdmin):
    list_display = ('code', 'discount_type', 'discount', 'valid_from', 'valid_to', 'active', 'description')
    list_filter = ('active', 'discount_type')
    search_fields = ('code', 'description')
    date_hierarchy = 'valid_from'

@admin.register(OneTimeCoupon)
class OneTimeCouponAdmin(admin.ModelAdmin):
    list_display = ('code', 'discount_type', 'discount', 'valid_from', 'valid_to', 'active', 'description')
    list_filter = ('active', 'discount_type')
    search_fields = ('code', 'description')
    date_hierarchy = 'valid_from'
    filter_horizontal = ('used_by',)
