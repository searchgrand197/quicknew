from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'special-coupons', views.SpecialCouponViewSet)
router.register(r'coupons-for-all', views.CouponForAllViewSet)
router.register(r'one-time-coupons', views.OneTimeCouponViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('validate/', views.CouponValidationView.as_view(), name='coupon-validate'),
] 