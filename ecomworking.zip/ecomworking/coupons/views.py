from django.shortcuts import render
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser, AllowAny
from rest_framework.views import APIView
from django.utils import timezone
from decimal import Decimal
from .models import SpecialCoupon, CouponForAll, OneTimeCoupon
from .serializers import SpecialCouponSerializer, CouponForAllSerializer, OneTimeCouponSerializer
from rest_framework.authtoken.models import Token
from django.core.exceptions import ObjectDoesNotExist
import logging
import traceback
from django.contrib.auth.models import User
from django.db.models import Q
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator

logger = logging.getLogger(__name__)

def get_user_from_session(session_data):
    """Helper function to get or create user from session data"""
    try:
        if not session_data:
            return None
            
        phone_number = session_data.get('user', {}).get('phoneNumber')
        if not phone_number:
            return None
            
        user = User.objects.filter(username=phone_number).first()
        if not user:
            user = User.objects.create_user(
                username=phone_number,
                password=phone_number
            )
        return user
    except Exception as e:
        logger.error(f"Error getting user from session: {str(e)}")
        logger.error(traceback.format_exc())
        return None

# Create your views here.

class SpecialCouponViewSet(viewsets.ModelViewSet):
    queryset = SpecialCoupon.objects.all()
    serializer_class = SpecialCouponSerializer
    permission_classes = [IsAdminUser]

    def get_permissions(self):
        if self.action in ['my_coupons', 'validate']:
            return [AllowAny()]
        return [IsAdminUser()]

    @action(detail=False, methods=['get'])
    def my_coupons(self, request):
        """Get coupons available for the current user"""
        try:
            # Try to get user from session data first
            user = get_user_from_session(request.data.get('user_session'))
            
            # If no user from session, try authenticated user
            if not user and request.user.is_authenticated:
                user = request.user
                
            if not user:
                logger.warning("No user found in session or authenticated")
                return Response([])
                
            now = timezone.now()
            coupons = self.queryset.filter(
                active=True,
                coupon_for=user
            )
            serializer = self.get_serializer(coupons, many=True)
            return Response(serializer.data)
        except Exception as e:
            logger.error(f"Error in my_coupons: {str(e)}")
            logger.error(traceback.format_exc())
            return Response([], status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class CouponForAllViewSet(viewsets.ModelViewSet):
    queryset = CouponForAll.objects.all()
    serializer_class = CouponForAllSerializer
    permission_classes = [IsAdminUser]

    def get_permissions(self):
        if self.action == 'available':
            return [AllowAny()]
        return [IsAdminUser()]

    @action(detail=False, methods=['get'])
    def available(self, request):
        """Get all active coupons that are currently valid"""
        try:
            now = timezone.now()
            coupons = self.queryset.filter(
                active=True,
                valid_from__lte=now,
                valid_to__gte=now
            )
            serializer = self.get_serializer(coupons, many=True)
            return Response(serializer.data)
        except Exception as e:
            logger.error(f"Error in available coupons: {str(e)}")
            logger.error(traceback.format_exc())
            return Response([], status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class OneTimeCouponViewSet(viewsets.ModelViewSet):
    queryset = OneTimeCoupon.objects.all()
    serializer_class = OneTimeCouponSerializer
    permission_classes = [IsAdminUser]

    def get_permissions(self):
        if self.action in ['available', 'validate']:
            return [AllowAny()]
        return [IsAdminUser()]

    @action(detail=False, methods=['get'])
    def available(self, request):
        """Get all active coupons that are currently valid and not used by the user"""
        try:
            # Try to get user from session data first
            user = get_user_from_session(request.data.get('user_session'))
            
            # If no user from session, try authenticated user
            if not user and request.user.is_authenticated:
                user = request.user
                
            now = timezone.now()
            coupons = self.queryset.filter(
                active=True,
                valid_from__lte=now,
                valid_to__gte=now
            )
            
            # If we have a user (from session or auth), exclude used coupons
            if user:
                coupons = coupons.exclude(used_by=user)
                
            serializer = self.get_serializer(coupons, many=True)
            return Response(serializer.data)
        except Exception as e:
            logger.error(f"Error in available one-time coupons: {str(e)}")
            logger.error(traceback.format_exc())
            return Response([], status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=True, methods=['post'])
    def use(self, request, pk=None):
        """Mark a coupon as used by the current user"""
        try:
            # Try to get user from session data first
            user = get_user_from_session(request.data.get('user_session'))
            
            # If no user from session, try authenticated user
            if not user and request.user.is_authenticated:
                user = request.user
                
            if not user:
                return Response(
                    {'error': 'User not found'},
                    status=status.HTTP_401_UNAUTHORIZED
                )
                
            coupon = self.get_object()
            if coupon.used_by.filter(id=user.id).exists():
                return Response(
                    {'error': 'Coupon already used'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            coupon.used_by.add(user)
            return Response({'status': 'coupon used'})
        except Exception as e:
            logger.error(f"Error marking coupon as used: {str(e)}")
            logger.error(traceback.format_exc())
            return Response(
                {'error': 'Error marking coupon as used'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

@method_decorator(csrf_exempt, name='dispatch')
class CouponValidationView(APIView):
    def post(self, request):
        try:
            logger.info("Starting coupon validation")
            logger.info(f"Request data: {request.data}")

            code = request.data.get('code')
            total_amount = request.data.get('total_amount', 0)

            logger.info(f"Received code: {code}, total_amount: {total_amount}")

            if not code:
                logger.warning("No coupon code provided")
                return Response({
                    'valid': False,
                    'error': 'Coupon code is required'
                }, status=status.HTTP_400_BAD_REQUEST)

            if not total_amount or float(total_amount) <= 0:
                logger.warning(f"Invalid total amount: {total_amount}")
                return Response({
                    'valid': False,
                    'error': 'Invalid total amount'
                }, status=status.HTTP_400_BAD_REQUEST)

            # Get user from session
            user = get_user_from_session(request.data.get('user_session'))
            if not user:
                logger.warning("No user found in session data")
                return Response({
                    'valid': False,
                    'error': 'User session required'
                }, status=status.HTTP_401_UNAUTHORIZED)
            logger.info(f"User authenticated: {user.id}")

            # Check all coupon types
            coupon = None
            error_message = None

            # Check SpecialCoupon
            try:
                logger.info(f"Checking SpecialCoupon for code: {code}")
                special_coupon = SpecialCoupon.objects.get(code=code, active=True)
                logger.info(f"Found SpecialCoupon: {special_coupon.id}")
                logger.info(f"SpecialCoupon details - min_purchase: {special_coupon.min_purchase_amount}, discount: {special_coupon.discount}")
                
                if special_coupon.coupon_for.filter(id=user.id).exists():
                    if float(total_amount) >= special_coupon.min_purchase_amount:
                        coupon = special_coupon
                        logger.info("SpecialCoupon is valid")
                    else:
                        error_message = f"Minimum purchase amount of ₹{special_coupon.min_purchase_amount} required"
                        logger.info(f"SpecialCoupon minimum amount not met: {error_message}")
                else:
                    error_message = "This coupon is not available for your account"
                    logger.info("SpecialCoupon not available for user")
            except SpecialCoupon.DoesNotExist:
                logger.info("No matching SpecialCoupon found")
            except Exception as e:
                logger.error(f"Error checking SpecialCoupon: {str(e)}")
                logger.error(traceback.format_exc())

            # Check CouponForAll
            if not coupon:
                try:
                    logger.info(f"Checking CouponForAll for code: {code}")
                    for_all_coupon = CouponForAll.objects.get(code=code, active=True)
                    logger.info(f"Found CouponForAll: {for_all_coupon.id}")
                    logger.info(f"CouponForAll details - min_purchase: {for_all_coupon.min_purchase_amount}, discount: {for_all_coupon.discount}")
                    
                    now = timezone.now()
                    if for_all_coupon.valid_from <= now <= for_all_coupon.valid_to:
                        if float(total_amount) >= for_all_coupon.min_purchase_amount:
                            coupon = for_all_coupon
                            logger.info("CouponForAll is valid")
                        else:
                            error_message = f"Minimum purchase amount of ₹{for_all_coupon.min_purchase_amount} required"
                            logger.info(f"CouponForAll minimum amount not met: {error_message}")
                    else:
                        error_message = "This coupon has expired"
                        logger.info(f"CouponForAll expired - valid_from: {for_all_coupon.valid_from}, valid_to: {for_all_coupon.valid_to}, now: {now}")
                except CouponForAll.DoesNotExist:
                    logger.info("No matching CouponForAll found")
                except Exception as e:
                    logger.error(f"Error checking CouponForAll: {str(e)}")
                    logger.error(traceback.format_exc())

            # Check OneTimeCoupon
            if not coupon:
                try:
                    logger.info(f"Checking OneTimeCoupon for code: {code}")
                    one_time_coupon = OneTimeCoupon.objects.get(code=code, active=True)
                    logger.info(f"Found OneTimeCoupon: {one_time_coupon.id}")
                    logger.info(f"OneTimeCoupon details - min_purchase: {one_time_coupon.min_purchase_amount}, discount: {one_time_coupon.discount}")
                    
                    # Check if user has already used this coupon
                    if one_time_coupon.used_by.filter(id=user.id).exists():
                        error_message = "You have already used this coupon"
                        logger.info("OneTimeCoupon already used by user")
                    else:
                        now = timezone.now()
                        if one_time_coupon.valid_from <= now <= one_time_coupon.valid_to:
                            if float(total_amount) >= one_time_coupon.min_purchase_amount:
                                coupon = one_time_coupon
                                logger.info("OneTimeCoupon is valid")
                            else:
                                error_message = f"Minimum purchase amount of ₹{one_time_coupon.min_purchase_amount} required"
                                logger.info(f"OneTimeCoupon minimum amount not met: {error_message}")
                        else:
                            error_message = "This coupon has expired"
                            logger.info(f"OneTimeCoupon expired - valid_from: {one_time_coupon.valid_from}, valid_to: {one_time_coupon.valid_to}, now: {now}")
                except OneTimeCoupon.DoesNotExist:
                    logger.info("No matching OneTimeCoupon found")
                except Exception as e:
                    logger.error(f"Error checking OneTimeCoupon: {str(e)}")
                    logger.error(traceback.format_exc())

            if coupon:
                try:
                    # Calculate discount
                    logger.info("Calculating discount")
                    if coupon.discount_type == 'percent':
                        discount_amount = (Decimal(str(total_amount)) * coupon.discount) / Decimal('100')
                        if hasattr(coupon, 'max_discount_amount') and coupon.max_discount_amount:
                            discount_amount = min(discount_amount, coupon.max_discount_amount)
                    else:
                        discount_amount = coupon.discount

                    final_amount = Decimal(str(total_amount)) - discount_amount
                    logger.info(f"Discount calculated: {discount_amount}, Final amount: {final_amount}")

                    # If it's a one-time coupon, mark it as used
                    if isinstance(coupon, OneTimeCoupon):
                        coupon.used_by.add(user)
                        logger.info(f"OneTimeCoupon marked as used by user {user.id}")

                    return Response({
                        'valid': True,
                        'coupon': {
                            'code': coupon.code,
                            'discount_type': coupon.discount_type,
                            'discount': coupon.discount,
                            'max_discount_amount': getattr(coupon, 'max_discount_amount', None),
                            'min_purchase_amount': coupon.min_purchase_amount,
                            'type': 'one_time' if isinstance(coupon, OneTimeCoupon) else 'for_all' if isinstance(coupon, CouponForAll) else 'special'
                        },
                        'discount_amount': float(discount_amount),
                        'final_amount': float(final_amount)
                    })
                except Exception as e:
                    logger.error(f"Error calculating discount: {str(e)}")
                    logger.error(traceback.format_exc())
                    raise
            else:
                logger.info(f"No valid coupon found. Error message: {error_message}")
                return Response({
                    'valid': False,
                    'error': error_message or 'Invalid or expired coupon code'
                }, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logger.error(f"Error in coupon validation: {str(e)}")
            logger.error(traceback.format_exc())
            return Response({
                'valid': False,
                'error': 'An error occurred while validating the coupon'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
