from django.core.management.base import BaseCommand
from dashboard.models import Item

class Command(BaseCommand):
    help = 'Resets all products to have no seller (admin/unassigned).'

    def handle(self, *args, **options):
        updated_count = 0
        for item in Item.objects.all():
            item.seller = None
            item.seller_code = None
            item.save()
            updated_count += 1
        self.stdout.write(self.style.SUCCESS(f'Successfully reset {updated_count} products to admin/unassigned.')) 