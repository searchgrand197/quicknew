from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    CategoryViewSet, SubCategoryViewSet, ItemViewSet, AffiliateLinkViewSet,
    OrderViewSet, ShareItemView, Subcategoryview, ListSigma, AdvertisementViewSet,
    UserViewSet, CustomerViewSet, AdvertisementViewSet1, OrderDashboardViewSet,
    refund_payment, SellerRequestViewSet, SellerProfileViewSet, seller_login,
    SellerOrderViewSet, SellerProductViewSet,
    AdminOrderViewSet, AdminProductViewSet, CustomerLoginView, CustomerRegisterView, CustomerRefreshTokenView, GetUserDetailsView
)

router = DefaultRouter()
router.register(r'categories', CategoryViewSet)
router.register(r'subcategories', SubCategoryViewSet)
router.register(r'items', ItemViewSet)
router.register(r'affiliate-links', AffiliateLinkViewSet)
router.register(r'a', OrderViewSet)
router.register(r'subfind', Subcategoryview,basename='subfind')
router.register(r'list', ListSigma,basename='catfind')
router.register(r'advertisements', AdvertisementViewSet)
router.register(r'users', UserViewSet)
router.register(r'customers', CustomerViewSet)
router.register(r'adnew', AdvertisementViewSet1, basename='advertisementnew')
router.register(r'order-dashboard', OrderDashboardViewSet)
router.register(r'seller-requests', SellerRequestViewSet, basename='seller-request')
router.register(r'seller-profiles', SellerProfileViewSet, basename='seller-profile')
router.register(r'seller/orders', SellerOrderViewSet, basename='seller-orders')
router.register(r'seller/products', SellerProductViewSet, basename='seller-products')
router.register(r'admin/orders', AdminOrderViewSet, basename='admin-orders')
router.register(r'admin/products', AdminProductViewSet, basename='admin-products')

urlpatterns = [
    path('', include(router.urls)),
    path('api/', include(router.urls)),
    path('api/seller-login/', seller_login, name='seller-login'),
    path('api/customer/login/', CustomerLoginView.as_view(), name='customer-login'),
    path('api/customer/register/', CustomerRegisterView.as_view(), name='customer-register'),
    path('api/customer/refresh/', CustomerRefreshTokenView.as_view(), name='customer-refresh'),
    path('api/customer/details/', GetUserDetailsView.as_view(), name='get-user-details'),
]
