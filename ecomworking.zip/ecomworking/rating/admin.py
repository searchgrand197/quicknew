from django.contrib import admin
from .models import Rating, RatingImage
from django.utils.html import format_html
from django.db.models import Avg

class RatingImageInline(admin.TabularInline):
    model = RatingImage
    extra = 0
    readonly_fields = ('image_preview',)
    
    def image_preview(self, obj):
        if obj.image:
            return format_html('<img src="{}" style="max-height: 50px; max-width: 50px;" />', obj.image.url)
        return "No image"
    image_preview.short_description = 'Preview'

@admin.register(Rating)
class RatingAdmin(admin.ModelAdmin):
    list_display = ('id', 'user_info', 'item_info', 'rating_stars', 'comment_preview', 'created_at', 'is_verified_purchase', 'rating_actions')
    list_filter = ('rating', 'is_verified_purchase', 'created_at', 'item__subcategory')
    search_fields = ('user__username', 'user__first_name', 'user__last_name', 'item__name', 'comment')
    readonly_fields = ('created_at', 'updated_at', 'rating_stars_display')
    inlines = [RatingImageInline]
    list_per_page = 25
    date_hierarchy = 'created_at'
    
    fieldsets = (
        ('Rating Information', {
            'fields': ('user', 'item', 'rating', 'rating_stars_display', 'comment')
        }),
        ('Verification', {
            'fields': ('is_verified_purchase',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def user_info(self, obj):
        if obj.user:
            return f"{obj.user.username} ({obj.user.first_name} {obj.user.last_name})"
        return "Anonymous"
    user_info.short_description = 'User'
    
    def item_info(self, obj):
        return f"{obj.item.name} (SKU: {obj.item.sku})"
    item_info.short_description = 'Product'
    
    def rating_stars(self, obj):
        if obj.rating:
            stars = "★" * obj.rating + "☆" * (5 - obj.rating)
            return f"{stars} ({obj.rating})"
        return "☆☆☆☆☆ (0)"
    rating_stars.short_description = 'Rating'
    
    def rating_stars_display(self, obj):
        if obj.rating:
            stars = "★" * obj.rating + "☆" * (5 - obj.rating)
            return f"{stars} ({obj.rating}/5)"
        return "☆☆☆☆☆ (0/5)"
    rating_stars_display.short_description = 'Rating Display'
    
    def comment_preview(self, obj):
        if obj.comment:
            return obj.comment[:50] + "..." if len(obj.comment) > 50 else obj.comment
        return "No comment"
    comment_preview.short_description = 'Comment'
    
    def rating_actions(self, obj):
        return format_html(
            '<a href="{}" class="button">View Details</a>',
            f'/admin/rating/rating/{obj.id}/change/'
        )
    rating_actions.short_description = 'Actions'
    
    actions = ['mark_verified', 'mark_unverified']
    
    def mark_verified(self, request, queryset):
        updated = queryset.update(is_verified_purchase=True)
        self.message_user(request, f'{updated} ratings marked as verified.')
    mark_verified.short_description = "Mark selected ratings as verified"
    
    def mark_unverified(self, request, queryset):
        updated = queryset.update(is_verified_purchase=False)
        self.message_user(request, f'{updated} ratings marked as unverified.')
    mark_unverified.short_description = "Mark selected ratings as unverified"

@admin.register(RatingImage)
class RatingImageAdmin(admin.ModelAdmin):
    list_display = ('id', 'rating_info', 'image_preview', 'uploaded_at')
    search_fields = ('rating__user__username', 'rating__item__name')
    readonly_fields = ('uploaded_at', 'image_preview')
    
    def rating_info(self, obj):
        user = obj.rating.user if obj.rating else None
        username = user.username if user else "Anonymous"
        item_name = obj.rating.item.name if obj.rating and obj.rating.item else "Unknown Item"
        return f"{username} - {item_name}"
    rating_info.short_description = 'Rating'
    
    def image_preview(self, obj):
        if obj.image:
            return format_html('<img src="{}" style="max-height: 100px; max-width: 100px;" />', obj.image.url)
        return "No image"
    image_preview.short_description = 'Image Preview'
